// Define the global variables: bottomImg and topImg.
let bottomImg, topImg;

function preload() {
  // Preload the images from the canvas's assets directory.
  // The bottomImg is the photograph with color,
  // and the topImg is the black-and-white photograph.
  bottomImg = loadImage('/assets/owl.jpg');
  topImg = loadImage('/assets/canal.jpg');
}
function setup() {

  createCanvas(720, 400);

  // Hide the cursor and replace it with a picture of
  // a paintbrush.
  noCursor();
  cursor('/assets/brush.svg.png', 20, -10);

  // Load the top image (the black-and-white image).
  image(topImg, 0, 0);
}
function mouseDragged() {
  // Using the copy() function, copy the bottom image
  // on top of the top image when you drag your cursor
  // across the canvas.
  copy(bottomImg, mouseX, mouseY, 20, 20, mouseX, mouseY, 20, 20);
}